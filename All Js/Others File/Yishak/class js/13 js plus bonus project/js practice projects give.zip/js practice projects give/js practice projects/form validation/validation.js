/* created by zelalem A for hilcoe students practice 2023 */

let form = document.getElementById("form");
let username = form.elements["username"];
let email = form.elements["email"];
let password = form.elements["password"];
let password2 = form.elements["password2"];
let img=document.querySelector('.title img')
img.style.display='none'

let gender = document.querySelectorAll("input[type=radio]");

form.addEventListener("submit", function (e) {
  e.preventDefault();
 validateForm()
});
function setError(element, message) {
  
}
function setSuccess(element) {
 
}

function validateForm() {

}


